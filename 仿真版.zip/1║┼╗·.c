/*
Send
*/

#include <reg51.h>

unsigned char UartBuffer = 0; //Recive Buffer
unsigned char ConfigFlag = 0;
unsigned char SetuptTimeFlag[2] = {0};
unsigned char PressedKey = 0;

void ConfigUART(unsigned int baud);
void ConfigExternalInterrupt();
unsigned char ConfirmPress();
void Delay_ms(unsigned char n);

void main()
{
	EA = 1; //Enable interrupt
	ConfigExternalInterrupt();//�ⲿ
	ConfigUART(9600); //Baud rate 9600
	P0 = 0xff;
	P2 = 0x00;
	while (1)
	{
		if (ConfirmPress())
		{
			if (PressedKey == 'R')
			{
				ConfigFlag = 0;
				SetuptTimeFlag[0] = 0;
				SetuptTimeFlag[1] = 0;
				SBUF = PressedKey;
				while (ConfirmPress())
				{
				}
				SBUF = PressedKey;
			}
			else if (ConfigFlag == 0 && PressedKey == 'S')
			{
				ConfigFlag = 'S';
				SBUF = PressedKey;
				while (ConfirmPress())
				{
					/* code */
				}
				SBUF = PressedKey;
			}
			else if (ConfigFlag == 'S')
			{
				if (PressedKey == 'h' || PressedKey == 'm' || PressedKey == 's')
				{
					ConfigFlag = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
			}
			else if (ConfigFlag == 'h')
			{
				if (SetuptTimeFlag[0] == 0 && PressedKey <= '2' && PressedKey >= '0')
				{
					SetuptTimeFlag[0] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if ((SetuptTimeFlag[1] == 0) && (SetuptTimeFlag[0] == '0' || SetuptTimeFlag[0] == '1') && PressedKey <= '9' && PressedKey >= '0')
				{
					SetuptTimeFlag[1] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if ((SetuptTimeFlag[1] == 0) && (SetuptTimeFlag[0] == '2') && PressedKey <= '3' && PressedKey >= '0')
				{
					SetuptTimeFlag[1] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && PressedKey == 'R')
				{
					ConfigFlag = 0;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && (PressedKey == 'h' || PressedKey == 'm' || PressedKey == 's'))
				{
					ConfigFlag = PressedKey;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
			}
			else if (ConfigFlag = 'm')
			{
				if (SetuptTimeFlag[0] == 0 && PressedKey <= '5' && PressedKey >= '0')
				{
					SetuptTimeFlag[0] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if ((SetuptTimeFlag[0] != 0) && PressedKey <= '9' && PressedKey >= '0')
				{
					SetuptTimeFlag[1] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && PressedKey == 'R')
				{
					ConfigFlag = 0;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && (PressedKey == 'h' || PressedKey == 'm' || PressedKey == 's'))
				{
					ConfigFlag = PressedKey;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
			}
			else if (ConfigFlag = 's')
			{
				if (SetuptTimeFlag[0] == 0 && PressedKey <= '5' && PressedKey >= '0')
				{
					SetuptTimeFlag[0] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if ((SetuptTimeFlag[0] != 0) && PressedKey <= '9' && PressedKey >= '0')
				{
					SetuptTimeFlag[1] = PressedKey;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && PressedKey == 'R')
				{
					ConfigFlag = 0;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
				else if (SetuptTimeFlag[1] != 0 && (PressedKey == 'h' || PressedKey == 'm' || PressedKey == 's'))
				{
					ConfigFlag = PressedKey;
					SetuptTimeFlag[0] = 0;
					SetuptTimeFlag[1] = 0;
					SBUF = PressedKey;
					while (ConfirmPress())
					{
						/* code */
					}
					SBUF = PressedKey;
				}
			}
		}
		// P1 = SetuptTimeFlag[1];
		P1 = PressedKey;
	}
}

/* Config Uart baud */
void ConfigUART(unsigned int baud)
{
	SCON = 0x50;							 //Mode 1
	TMOD &= 0x0F;							 //Clear T1 Flag
	TMOD |= 0x20;							 //setup T1 Mode2
	TH1 = 256 - (11059200 / 12 / 32) / baud; //Compute T1 reload Value
	TL1 = TH1;								 //init Val=Reload Val
	ET1 = 0;								 //Disable T1 interrupt
	ES = 1;									 //Enable Timer
	TR1 = 1;								 //Enable T1
}

//Config External Interrupt
void ConfigExternalInterrupt()
{
	EX0 = 1; //Enable external interrupt
	IT0 = 1; //Falling edge trigger
}

void Delay_ms(unsigned char n)
{
	unsigned char i, j;
	for (i = n; i > 0; i--)
	{
		j = 114;
		while (j)
		{
			j--;
		}
	}
}

unsigned char ConfirmPress()
{
	P0 = 0xff;
	P2 = 0x00;
	if (P0 == 0xff)
	{
		PressedKey = 0;
	}
	return PressedKey;
}

/* UART Interrupt Handler */
void InterruptUART() interrupt 4
{
	if (RI)
	{					   //Recive
		RI = 0;			   //Clear Interrupt flag
		UartBuffer = SBUF; //Save to buffer
	}
	if (TI)
	{			//Send
		TI = 0; //Clear Send Interrupt
	}
}

// External Interrupt Handder
void EXIT0_IRQ(void) interrupt 0
{
	unsigned char KayTemp = P0;

	if (P0 == 0xfe)
	{
		P2 = 0x01;
		Delay_ms(10); //消抖
		if (KayTemp != P0)
		{
			PressedKey = '1';
		}
		P2 = 0x02;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '2';
		}
		P2 = 0x04;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '3';
		}
		P2 = 0x08;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 'h';
		}
	}
	if (P0 == 0xfd)
	{
		P2 = 0x01;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '4';
		}
		P2 = 0x02;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '5';
		}
		P2 = 0x04;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '6';
		}
		P2 = 0x08;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 'm';
		}
	}
	if (P0 == 0xfb)
	{
		P2 = 0x01;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '7';
		}
		P2 = 0x02;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '8';
		}
		P2 = 0x04;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '9';
		}
		P2 = 0x08;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 's';
		}
	}
	if (P0 == 0xf7)
	{
		P2 = 0x01;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 'T';
		}
		P2 = 0x02;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = '0';
		}
		P2 = 0x04;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 'R';
		}
		P2 = 0x08;
		Delay_ms(10);
		if (KayTemp != P0)
		{
			PressedKey = 'S';
		}
	}
	P0 = 0xff;
	P2 = 0x00;
	EX0 = 1;
}
