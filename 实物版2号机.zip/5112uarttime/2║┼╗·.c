/*
Recive
*/

#include <reg51.h>

unsigned char RxdByte = 0; //Recive Buffer

unsigned char SetupFlag = 0; //Setup Satus
unsigned char TIME_BASE = 0; //Timer Base Counter
unsigned char Time_H = 0;
unsigned char Time_M = 0; //Time
unsigned char Time_S = 0;
unsigned char Display_H[2] = {0};
unsigned char Display_M[2] = {0}; //Displayed numbers
unsigned char Display_S[2] = {0};
unsigned char DisplayMap[13] = {
	0xc0, //0
	0xf9, //1
	0xa4, //2
	0xb0, //3
	0x99, //4
	0x92, //5
	0x82, //6
	0xf8, //7
	0x80, //8
	0x90, //9
	0xff, //None
	0xf6, //A,D,Slash
	0xbf, //G,Slash
};		  //Used Array to show num

void ConfigUART(unsigned int baud); //config uart with baud
void EnableBaseTimer();				//enable timer
void DisableBaseTimer();			//disable timer
void DisplayTime();					//display time to LCD
void Delay_ms(unsigned char n);		//ms delay
void RefreshFlag();					//Refresh config status

void main()
{
	EA = 1;			  //Enable interrupt
	ConfigUART(9600); //Baud rate 9600
	EnableBaseTimer();
	while (1)
	{
		DisplayTime();
	}
}

/* Config Uart baud */
void ConfigUART(unsigned int baud)
{
	SCON = 0x50;							 //Mode 1
	TMOD &= 0x0F;							 //Clear T1 Flag
	TMOD |= 0x20;							 //setup T1 Mode2
	TH1 = 256 - (11059200 / 12 / 32) / baud; //Compute T1 reload Value
	TL1 = TH1;								 //init Val=Reload Val
	ET1 = 0;								 //Disable T1 interrupt
	ES = 1;									 //Enable Uart interrupt
	TR1 = 1;								 //Enable T1
}

/* Config Count timer */
void EnableBaseTimer()
{
	TMOD &= 0xF0;				 //Clear T2 Flag
	TMOD |= 0x01;				 //setup T2 Mode 1
	TH0 = (65536 - 18432) / 256; // 20ms  @ 11.0592MHZ
	TL0 = (65536 - 18432) % 256;
	ET0 = 1; //Disable T0 interrupt
	TR0 = 1; //Enable T0
}

void DisableBaseTimer()
{
	ET0 = 0;
	TR0 = 0;
}

void Delay_ms(unsigned char n)
{
	unsigned char i, j;
	for (i = n; i > 0; i--)
	{
		j = 114;
		while (j)
		{
			j--;
		}
	}
}
void RefreshFlag()
{
	SetupFlag = RxdByte;
	if (SetupFlag == 'h')
	{
		Display_H[0] = 11;
		Display_H[1] = 11;
	}
	else if (SetupFlag == 'm')
	{
		Display_M[0] = 11;
		Display_M[1] = 11;
	}
	else if (SetupFlag == 's')
	{
		Display_S[0] = 11;
		Display_S[1] = 11;
	}
}
/*LCD Display*/
void DisplayTime()
{
	//if not in config mode,calculate 6 num and show
	if (SetupFlag == 0)
	{
		Display_S[1] = Time_S % 10; //��λ
		Display_S[0] = Time_S / 10;
		Display_M[1] = Time_M % 10;
		Display_M[0] = Time_M / 10;
		Display_H[1] = Time_H % 10;
		Display_H[0] = Time_H / 10;
	}
	
	//P0=0xff;
	P1 = 0xff;
	
	P0 = 0x7f;//0x7f
	P1 = DisplayMap[Display_S[1]];
	Delay_ms(1);
	//P0 = 0x7f;//0x7f
	P1 = 0xff;

	P0 = 0xbf;//0xbf
	P1 = DisplayMap[Display_S[0]];
	Delay_ms(1);
	//P0 = 0xbf;//0xbf
	P1 = 0xff;

	P0 = 0xdf; //0xdf
	P1 = DisplayMap[12];
	Delay_ms(1);
	//P0 = 0xdf; //0xdf
		P1 = 0xff;

	P0 = 0xef; //0xef
	P1 = DisplayMap[Display_M[1]];
	Delay_ms(1);
	//P0 = 0xef; //0xef
		P1 = 0xff;

	P0 = 0xf7; //0xf7 0111
	P1 = DisplayMap[Display_M[0]];
	Delay_ms(1);
	//P0 = 0xf7; //0xf7 0111
	P1 = 0xff;

	P0 = 0xfb; //0xfb 1011
	P1 = DisplayMap[12];
	Delay_ms(1);
	//P0 = 0xfb; //0xfb 1011
		P1 = 0xff;

	P0 = 0xfd; //0xfd 1101
	P1 = DisplayMap[Display_H[1]];
	Delay_ms(1);
	//P0 = 0xfd; //0xfd 1101
		P1 = 0xff;

  P0 = 0xfe; //0xfe 1110
	P1 = DisplayMap[Display_H[0]];
	Delay_ms(1);
	//P0 = 0xfe; //0xfe 1110
		P1 = 0xff;
}

/* UART Interrupt Handler */
void Uart_IRQ() interrupt 4
{
	if (RI)
	{					//Recive
		RI = 0;			//Clear Interrupt flag
		RxdByte = SBUF; //Save to buffer
		P2 = Time_H;  //debug
		if (SetupFlag == 0 && RxdByte == 'S')
		{
			SetupFlag = RxdByte;
			DisableBaseTimer();
			//Uncomment those lines->???S??,????????
			//comment those lines->	???S??,??????
			// Display_H[0] = 0;
			// Display_H[1] = 0;
			// Display_M[0] = 0;
			// Display_M[1] = 0;
			// Display_S[0] = 0;
			// Display_S[1] = 0;
			// Time_H = 0;
			// Time_M = 0;
			// Time_S = 0;
		}
		else if ((SetupFlag == 'S') && (RxdByte == 'h' || RxdByte == 'm' || RxdByte == 's'))
		{
			RefreshFlag();
		}
		else if (SetupFlag == 'h')
		{
			P2 = Display_H[0];
			if (Display_H[0] == 11 && RxdByte <= '2' && RxdByte >= '0')
			{
				Display_H[0] = RxdByte - 48;
			}
			else if (Display_H[0] != 11 && Display_H[1] == 11 && RxdByte <= '9' && RxdByte >= '0')
			{
				Display_H[1] = RxdByte - 48;
			}
			else if (Display_H[1] != 11 && RxdByte == 'R')
			{
				Time_H = Display_H[0] * 10 + Display_H[1];
				EnableBaseTimer();
				SetupFlag = 0;
			}
			else if (Display_H[1] != 11 && (RxdByte == 'h' || RxdByte == 'm' || RxdByte == 's'))
			{
				Time_H = Display_H[0] * 10 + Display_H[1];
				RefreshFlag();
			}
		}
		else if (SetupFlag == 'm')
		{
			if (Display_M[0] == 11 && RxdByte <= '9' && RxdByte >= '0')
			{
				Display_M[0] = RxdByte - 48;
			}
			else if (Display_M[0] != 11 && Display_M[1] == 11 && RxdByte <= '9' && RxdByte >= '0')
			{
				Display_M[1] = RxdByte - 48;
			}
			else if (Display_M[1] != 11 && RxdByte == 'R')
			{
				Time_M = Display_M[0] * 10 + Display_M[1];
				EnableBaseTimer();
				SetupFlag = 0;
			}
			else if (Display_H[1] != 11 && (RxdByte == 'h' || RxdByte == 'm' || RxdByte == 's'))
			{
				Time_M = Display_M[0] * 10 + Display_M[1];
				RefreshFlag();
			}
		}
		else if (SetupFlag == 's')
		{
			if (Display_S[0] == 11 && RxdByte <= '9' && RxdByte >= '0')
			{
				Display_S[0] = RxdByte - 48;
			}
			else if (Display_S[0] != 11 && Display_S[1] == 11 && RxdByte <= '9' && RxdByte >= '0')
			{
				Display_S[1] = RxdByte - 48;
			}
			else if (Display_S[1] != 11 && RxdByte == 'R')
			{
				Time_S = Display_S[0] * 10 + Display_S[1];
				EnableBaseTimer();
				SetupFlag = 0;
			}
			else if (Display_S[1] != 11 && (RxdByte == 'h' || RxdByte == 'm' || RxdByte == 's'))
			{
				Time_S = Display_S[0] * 10 + Display_S[1];
				RefreshFlag();
			}
		}
	}
	if (TI)
	{			//Send
		TI = 0; //Clear Send Interrupt
	}
}

void Timer0_IRQ(void) interrupt 1
{
	TH0 = (65536 - 18432) / 256;
	TL0 = (65536 - 18432) % 256;
	/* Enter interrupt per 20ms */
	TIME_BASE++;
	if (TIME_BASE == 50) //	20ms * 50 = 1000ms = 1s
	{
		//Change Time
		TIME_BASE = 0;
		Time_S++;		  // Second Count
		if (Time_S >= 60) // Minute Count
		{
			Time_S = 0;
			Time_M++;
			if (Time_M >= 60) // Hour Count
			{
				Time_M = 0;
				Time_H++;
				if (Time_H >= 24) //Day Count
				{
					Time_H = 0;
					Time_M = 0;
					Time_S = 0;
				}
			}
		}
	}
}
